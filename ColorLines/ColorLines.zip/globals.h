////globals.h
////global nonconstant variables
//#pragma once
//#ifndef GLOBALS_H
//#define GLOBALS_H
//
//#include <Windows.h>
//#include "Field.h"
//
//HDC hDc;
//PAINTSTRUCT ps;
//static Field field;
//int *way = 0;
//static Square from;
//static Square to;
//char *bif= new char[ 100 ];
//
//int click_counter = 0;
//
//#endif GLOBALS_H