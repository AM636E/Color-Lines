#pragma once
#ifndef MESSAGE_PROTO_H
#define MESSAGE_PROTO_H
#include <Windows.h>

void OnPaint( HWND hWnd );
void OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);

#endif MESSAGE_PROTO_H