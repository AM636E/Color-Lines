//definit.h
//global definitions and constants

#pragma once

const int SIZE_X = 50;
const int SIZE_Y = 50;

const int SQUARES_X = 9;
const int SQUARES_Y = 9;

const int WALL = -1;
const int WAY  =  0;